(function(){

  const config = {
    apiKey: "AIzaSyAc5YOYrnvFgRcfXazXP52w9vxOUO4M1e0",
    authDomain: "resto-2eb0a.firebaseapp.com",
    databaseURL: "https://resto-2eb0a.firebaseio.com",
    projectId: "resto-2eb0a",
    storageBucket: "resto-2eb0a.appspot.com",
    messagingSenderId: "800932025890",
  };

  var name = $('.validate-input input[name="name"]');
  var email = $('.validate-input input[name="email"]');
  var password = $('.validate-input input[name="password"]');

  firebase.initializeApp(config);
  var txtEmail = document.getElementById('txtEmail');
  var txtPassword = document.getElementById('txtPassword');
  var btnSignUp = document.getElementById('btnSignUp');



  btnSignUp.addEventListener('click',e =>{
      var check = true;
      if($(name).val().trim() == ''){
          showValidate(name);
          check=false;
      }

      if($(email).val().trim().match(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)$/) == null) {
          showValidate(email);
          check=false;
      }

      if(($(password).val().trim()=='') || ($(password).val().length < 8)){
          showValidate(password);
          check=false;
      }
  });

  $('.validate-form .input100').each(function(){
      $(this).focus(function(){
         hideValidate(this);
     });
  });

  function showValidate(input) {
      var thisAlert = $(input).parent();
      $(thisAlert).addClass('alert-validate');
  }

  function hideValidate(input) {
      var thisAlert = $(input).parent();
      $(thisAlert).removeClass('alert-validate');
  }

  btnSignUp.addEventListener('click',e =>{
    var email = txtEmail.value;
    var pass = txtPassword.value;
    var auth = firebase.auth();

    var sel = document.getElementById('selType');
    var opt = sel.options[sel.selectedIndex];

    var temp = email;
    temp = temp.replace('@','');
    temp = temp.replace(/\./g,'');

    firebase.database().ref('/users/unverified/'+temp).set({
      restaurant: document.getElementById("codeH").innerHTML,
      email: email,
      type: opt.value,
    });

    const promise = auth.createUserWithEmailAndPassword(email,pass);
    promise.catch(e=>console.log(e.message));
  });

  firebase.auth().onAuthStateChanged(firebaseUser => {
    if(firebaseUser){
      console.log(firebaseUser);

      window.location.href = 'login.html';

      btnLogout.classList.remove('hide');
    } else {
      console.log('not logged in');
      btnLogout.classList.add('hide');
    }
  });

  function guid() {
    return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
  }

  function s4() {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
  }
}());
