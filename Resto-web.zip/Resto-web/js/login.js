(function() {
  const config = {
    apiKey: "AIzaSyAc5YOYrnvFgRcfXazXP52w9vxOUO4M1e0",
    authDomain: "resto-2eb0a.firebaseapp.com",
    databaseURL: "https://resto-2eb0a.firebaseio.com",
    projectId: "resto-2eb0a",
    storageBucket: "resto-2eb0a.appspot.com",
    messagingSenderId: "800932025890",
  };

  firebase.initializeApp(config);
  var email = $('.validate-input input[name="email"]');
  var password = $('.validate-input input[name="password"]');

  document.getElementById('Btnlogin').addEventListener('click',e =>{
      var check = true;

      if(($(password).val().trim()=='')){
          showValidate(password);
          check=false;
      }

      document.getElementById('error_msg').innerHTML = "";
      if(check){
        var userEmail = document.getElementById("email_field").value;
        var userPass = document.getElementById("password_field").value;

        firebase.auth().signInWithEmailAndPassword(userEmail, userPass).catch(function(error) {
          var errorCode = error.code;
          var errorMessage = error.message;
          document.getElementById('error_msg').innerHTML = errorMessage;
        });

      }
  });

  $('.validate-form .input100').each(function(){
      $(this).focus(function(){
         hideValidate(this);
     });
  });

  function showValidate(input) {
      var thisAlert = $(input).parent();
      $(thisAlert).addClass('alert-validate');
  }

  function hideValidate(input) {
      var thisAlert = $(input).parent();
      $(thisAlert).removeClass('alert-validate');
  }

  /*document.getElementById("Btnlogout").onclick = function(){
    console.log("LOGOUT");
    firebase.auth().signOut();
  }*/

  firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
      var user = firebase.auth().currentUser;

      if(user != null){
        var email_id = user.email;
        document.getElementById("user_para").innerHTML = "Welcome User : " + email_id + " Verification : " + user.emailVerified;
        if(user.emailVerified){
          var temp = email_id;
          temp = temp.replace('@','');
          temp = temp.replace(/\./g,'');

          firebase.database().ref('users/verified/').once('value', function(snapshot) {
            if (snapshot.hasChild(firebase.auth().currentUser.uid)) {
              var rootRef = firebase.database().ref('users/verified/'+firebase.auth().currentUser.uid);
            }else{
              var rootRef = firebase.database().ref('users/unverified/'+temp);
            }

            var rtype;
            console.log(rootRef);
            rootRef.on('value',function(snapshot){
              firebase.database().ref('users/verified/'+firebase.auth().currentUser.uid).set({
                userid: snapshot.child('userid').val(),
                restaurant: snapshot.child('restaurant').val(),
                email: snapshot.child('email').val(),
                type : snapshot.child('type').val()
              });
              console.log(snapshot.child('type').val());
              rtype = snapshot.child('type').val();
              console.log(rtype);
              console.log(rtype+"--"+firebase.database().ref().child('/users').child('unverified').child(temp));
              if(rtype=="Manager"){
                window.location.href = './Manager/manager.html';
              } else if(rtype=="Waiter"){
                window.location.href = './waiter/waiter.html';
              } else if(rtype=="Kitchen"){
                window.location.href = './kitchen/kitchen.html';
              }
            });
          });
        } else{
          document.getElementById('error_msg').innerHTML = "Email verification link has been sent";
          user.sendEmailVerification().then(function(){
            console.log("Sent");
          }).catch(function(error){
            console.log(error);
          });
        }
      }
    }else{
      console.log("Nope");
    }
  });
}());
