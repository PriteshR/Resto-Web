(function() {
  const config = {
    apiKey: "AIzaSyAc5YOYrnvFgRcfXazXP52w9vxOUO4M1e0",
    authDomain: "resto-2eb0a.firebaseapp.com",
    databaseURL: "https://resto-2eb0a.firebaseio.com",
    projectId: "resto-2eb0a",
    storageBucket: "resto-2eb0a.appspot.com",
    messagingSenderId: "800932025890",
  };

  firebase.initializeApp(config);

  var exOnce = (function() {
    var executed = false;
    return function() {
        if (!executed) {
            executed = true;
            getOrders();
        }
    };
  })();

  function getOrders(){
    var ref = firebase.database().ref('users/verified/'+firebase.auth().currentUser.uid);
    ref.on("value", function(snapshot) {
      var rootRef = firebase.database().ref();
      resid = snapshot.child('restaurant').val();
      var urlRef = rootRef.child("restaurants/"+resid+"/tables");
      urlRef.once("value", function(snapshot) {
        snapshot.forEach(function(child) {
          var name,quantity,category,tname,fint;
          tname = child.key;
          var abc = rootRef.child("restaurants/"+resid+"/tables/"+tname+"/name");
          abc.once('value').then(function(snapshot) {
            fint = snapshot.val();
            console.log(snapshot.val());
          });
          var urlR = rootRef.child("restaurants/"+resid+"/tables/"+tname+"/RecentOrder");

          urlR.once("value", function(snapshot) {
            snapshot.forEach(function(child) {
              console.log(child.key);

              var urlR = rootRef.child("restaurants/"+resid+"/tables/"+tname+"/RecentOrder/"+child.key);
              urlR.once("value", function(snapshot) {
                snapshot.forEach(function(child) {
                      if(child.key=="name"){
                        console.log(child.val());
                        name = child.val();
                      }
                      if(child.key=="quantity"){
                        console.log(child.val());
                        quantity = child.val();
                      }
                      if(child.key=="category"){
                        console.log(child.val());
                        category = child.val();
                      }
                  });
                  AddTable(name,quantity,category,fint);
                });
              });
            });
          });
        });
      });
  }

  function AddTable(name,quantity,category,tname){
    var table = document.getElementById("Selecteditems");
    var tr = document.createElement("tr");
    var td1 = document.createElement("td");
    var txt1 = document.createTextNode(name);
    var td2 = document.createElement("td");
    var txt2 = document.createTextNode(category);
    var td3 = document.createElement("td");
    var txt3 = document.createTextNode(quantity);
    var td4 = document.createElement("td");
    var txt4 = document.createTextNode(tname);
    td1.appendChild(txt1);
    td2.appendChild(txt2);
    td3.appendChild(txt3);
    td4.appendChild(txt4);
    tr.appendChild(td1);
    tr.appendChild(td2);
    tr.appendChild(td3);
    tr.appendChild(td4);
    table.appendChild(tr);
  }

  firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
      exOnce();
    }else{
      console.log("Nope");
    }
  });
}());
