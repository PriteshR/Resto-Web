(function() {
  const config = {
    apiKey: "AIzaSyAc5YOYrnvFgRcfXazXP52w9vxOUO4M1e0",
    authDomain: "resto-2eb0a.firebaseapp.com",
    databaseURL: "https://resto-2eb0a.firebaseio.com",
    projectId: "resto-2eb0a",
    storageBucket: "resto-2eb0a.appspot.com",
    messagingSenderId: "800932025890",
  };

  firebase.initializeApp(config);

  function getItemsOnLoad(){
    var ref = firebase.database().ref('users/verified/'+firebase.auth().currentUser.uid);
    ref.on("value", function(snapshot) {
      var rootRef = firebase.database().ref();
      resid = snapshot.child('restaurant').val();
      var urlRef = rootRef.child("restaurants/"+resid+"/menu/items");
      urlRef.once("value", function(snapshot) {
        snapshot.forEach(function(child) {
          var name,price,category;
          var urlR = rootRef.child("restaurants/"+resid+"/menu/items/"+child.key);
          urlR.once("value", function(snapshot) {
          snapshot.forEach(function(child) {
                if(child.key=="name"){
                  name = child.val();
                }
                if(child.key=="price"){
                  price = child.val();
                }
                if(child.key=="category"){
                  category = child.val();
                }
            });
            AddItem(name,price,category,0);
          });
        });
      });
    });
  }

  function getCategoriesOnLoad(){
    var ref = firebase.database().ref('users/verified/'+firebase.auth().currentUser.uid);
    ref.on("value", function(snapshot) {
      console.log(snapshot.child('restaurant').val());

      var rootRef = firebase.database().ref();
      resid = snapshot.child('restaurant').val();
      var urlRef = rootRef.child("restaurants/"+resid+"/menu/categories");
      urlRef.once("value", function(snapshot) {
        snapshot.forEach(function(child) {
          var name;
          var urlR = rootRef.child("restaurants/"+resid+"/menu/categories/"+child.key);
          urlR.once("value", function(snapshot) {
          snapshot.forEach(function(child) {
                if(child.key=="name"){
                  name = child.val();
                }
            });
            AddCategory(name,0);
          });
        });
      });
    });
  }

  function getCatList(){
    console.log("executed getCat");
    var name = [];
    name.length = 0;
    document.getElementById("categoryList").innerHTML = "";
    var ref = firebase.database().ref('users/verified/'+firebase.auth().currentUser.uid);
    ref.on("value", function(snapshot) {
      console.log(snapshot.child('restaurant').val());
      var rootRef = firebase.database().ref();
      resid = snapshot.child('restaurant').val();
      var urlRef = rootRef.child("restaurants/"+resid+"/menu/categories");
      urlRef.once("value", function(snapshot) {
        snapshot.forEach(function(child) {
          var urlR = rootRef.child("restaurants/"+resid+"/menu/categories/"+child.key);
          urlR.once("value", function(snapshot) {
          snapshot.forEach(function(child) {
                if(child.key=="name"){
                  name.push(child.val());
                  var x = document.getElementById("categoryList");
                  var c = document.createElement("option");
                  c.text = child.val();
                  x.options.add(c);
                  console.log(child.val());
                }
            });
          });
        });
      });
    });
  }

  document.getElementById('addItem').onclick = function(){
    console.log("executed");
    var e = document.getElementById("categoryList");
    var strUser = e.options[e.selectedIndex].text;
    AddItem(document.getElementById('itemName').value,document.getElementById('itemPrice').value,strUser,1)
  }

  document.getElementById('addCategory').onclick = function(){
    console.log("executed");
    AddCategory(document.getElementById('catName').value,1);
  }

  function AddItem(name,price,category,a){
    console.log('second');
    var table = document.getElementById("items");
    var tr = document.createElement("tr");
    var td2 = document.createElement("td");
    var txt2 = document.createTextNode(name);
    var td3 = document.createElement("td");
    var txt3 = document.createTextNode(category);
    var td4 = document.createElement("td");
    var txt4 = document.createTextNode(price);
    td3.setAttribute('class','text-primary');
    td2.appendChild(txt2);
    td3.appendChild(txt3);
    td4.appendChild(txt4);
    tr.appendChild(td2);
    tr.appendChild(td3);
    tr.appendChild(td4);
    table.appendChild(tr);
    if(a==1){
      addFireItem(name,price,category);
    }
  }

  function AddCategory(name,a){
    console.log('second');
    var table = document.getElementById("category");
    var tr = document.createElement("tr");
    var td2 = document.createElement("td");
    var txt2 = document.createTextNode(name);

    td2.appendChild(txt2);
    tr.appendChild(td2);
    table.appendChild(tr);
    if(a==1){
      addFireCategory(name);
      getCatList();
    }
  }

  function addFireCategory(name){
    var ref = firebase.database().ref('users/verified/'+firebase.auth().currentUser.uid);
    ref.on("value", function(snapshot) {
       var addRes = firebase.database().ref("restaurants/"+snapshot.child('restaurant').val());
       let WaiterAdd = {
         name: name
       }
       addRes.child('menu/categories').push(WaiterAdd);
     }, function (error) {
       console.log("Error: " + error.code);
    });
  }

  function addFireItem(name,price,category){
    var ref = firebase.database().ref('users/verified/'+firebase.auth().currentUser.uid);
    ref.on("value", function(snapshot) {
       var addRes = firebase.database().ref("restaurants/"+snapshot.child('restaurant').val());
       let WaiterAdd = {
         name: name,
         price: price,
         category: category
       }
       addRes.child('menu/items').push(WaiterAdd);
     }, function (error) {
       console.log("Error: " + error.code);
    });
  }

  var exOnce = (function() {
    var executed = false;
    return function() {
        if (!executed) {
            executed = true;
            getItemsOnLoad();
            getCategoriesOnLoad();
            getCatList();
        }
    };
})();

  firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
      exOnce();
    }else{
      console.log("Nope");
    }
  });
}());
