(function() {
  const config = {
    apiKey: "AIzaSyAc5YOYrnvFgRcfXazXP52w9vxOUO4M1e0",
    authDomain: "resto-2eb0a.firebaseapp.com",
    databaseURL: "https://resto-2eb0a.firebaseio.com",
    projectId: "resto-2eb0a",
    storageBucket: "resto-2eb0a.appspot.com",
    messagingSenderId: "800932025890",
  };

  firebase.initializeApp(config);

  function getStaffOnLoad(){
    var ref = firebase.database().ref('users/verified/'+firebase.auth().currentUser.uid);
    ref.on("value", function(snapshot) {
      var rootRef = firebase.database().ref();
      resid = snapshot.child('restaurant').val();
      var urlRef = rootRef.child("restaurants/"+resid+"/waiters");
      urlRef.once("value", function(snapshot) {
        snapshot.forEach(function(child) {
          var email,salary;
          var urlR = rootRef.child("restaurants/"+resid+"/waiters/"+child.key);
          urlR.once("value", function(snapshot) {
          snapshot.forEach(function(child) {
                if(child.key=="email"){
                  email = child.val();
                }
                if(child.key=="salary"){
                  salary = child.val();
                }
            });
            AddStaff(document.getElementById('WaiterT'),email,salary,0);
          });
        });
      });
    });
  }

  function getStaffOnLoadKitchen(){
    var ref = firebase.database().ref('users/verified/'+firebase.auth().currentUser.uid);
    ref.on("value", function(snapshot) {
      console.log(snapshot.child('restaurant').val());

      var rootRef = firebase.database().ref();
      resid = snapshot.child('restaurant').val();
      var urlRef = rootRef.child("restaurants/"+resid+"/kitchen");
      urlRef.once("value", function(snapshot) {
        snapshot.forEach(function(child) {
          var email,salary;
          var urlR = rootRef.child("restaurants/"+resid+"/kitchen/"+child.key);
          urlR.once("value", function(snapshot) {
          snapshot.forEach(function(child) {
                if(child.key=="email"){
                  email = child.val();
                }
                if(child.key=="salary"){
                  salary = child.val();
                }
            });
            AddStaff(document.getElementById('KitchenT'),email,salary,0);
          });
        });
      });
    });
  }

  document.getElementById('addW').onclick = function(){
    console.log("executed");
    var bool = null;
    var exec = false;

    var ref = firebase.database().ref('users/verified/'+firebase.auth().currentUser.uid);
    var resid;
    ref.on("value", function(snapshot) {
      console.log(snapshot.child('restaurant').val());
      var rootRef = firebase.database().ref();
      resid = snapshot.child('restaurant').val();
    });


    firebase.database().ref().child('users/verified').orderByChild('email').equalTo(document.getElementById('waiterEmail').value).on("value", function(snapshot) {
      if(snapshot.val()!=null){
        snapshot.forEach(function(data) {
          console.log(data.key);
          bool = data.key;
          console.log(bool);
          if(bool != null){
            var rootRef = firebase.database().ref('users/verified/'+bool);
            rootRef.on('value',function(snapshot){
              if(snapshot.child('employed').val()==null || snapshot.child('employed').val() == "false"){
                exec=true;
                firebase.database().ref('users/verified/' + bool).update({
                  employed : "true",
                  restaurant : resid
                });
                AddStaff(document.getElementById('WaiterT'),document.getElementById('waiterEmail').value,document.getElementById('waiterSalary').value,1);
              }

              if (snapshot.child('employed').val()=="true" && exec == false) {
                document.getElementById('er_msgw').innerHTML = "Already Employed";
              }
            });
          }
        });
      } else {
        document.getElementById('er_msgw').innerHTML = "Invalid User";
      }
    });
  }

  document.getElementById('addK').onclick = function(){
    console.log("executed");
    var bool = null;
    var exec = false;

    var ref = firebase.database().ref('users/verified/'+firebase.auth().currentUser.uid);
    var resid;
    ref.on("value", function(snapshot) {
      console.log(snapshot.child('restaurant').val());
      var rootRef = firebase.database().ref();
      resid = snapshot.child('restaurant').val();
    });

    firebase.database().ref().child('users/verified').orderByChild('email').equalTo(document.getElementById('kitchenEmail').value).on("value", function(snapshot) {
      if(snapshot.val()!=null){
        snapshot.forEach(function(data) {
          console.log(data.key);
          bool = data.key;
          console.log(bool);
          if(bool != null){
            var rootRef = firebase.database().ref('users/verified/'+bool);
            rootRef.on('value',function(snapshot){
              if(snapshot.child('employed').val()==null || snapshot.child('employed').val() == "false"){
                exec=true;
                firebase.database().ref('users/verified/' + bool).update({
                  employed : "true",
                  restaurant : resid
                });
                AddStaff(document.getElementById('KitchenT'),document.getElementById('kitchenEmail').value,document.getElementById('kitchenSalary').value,1);
              }

              if (snapshot.child('employed').val()=="true" && exec == false) {
                document.getElementById('er_msgk').innerHTML = "Already Employed";
              }
            });
          }
        });
      } else {
        document.getElementById('er_msgw').innerHTML = "Invalid User";
      }
    });
  }

  function AddStaff(table,email,salary,a){
    console.log('second');
    var table = table;
    var tr = document.createElement("tr");
    // var td1 = document.createElement("td");
    // var txt1 = document.createTextNode("1");
    var td2 = document.createElement("td");
    var txt2 = document.createTextNode(email);
    var td3 = document.createElement("td");
    var txt3 = document.createTextNode(salary);
    td3.setAttribute('class','text-primary');

    //td1.appendChild(txt1);
    td2.appendChild(txt2);
    td3.appendChild(txt3);
    //tr.appendChild(td1);
    tr.appendChild(td2);
    tr.appendChild(td3);
    table.appendChild(tr);
    if(a==1){
      if(table==document.getElementById('WaiterT')){
        addFireStaff(email,salary);
      } else{
        addFireKitchen(email,salary);
      }
    }
  }

  function addFireStaff(email_id,salary){
    var ref = firebase.database().ref('users/verified/'+firebase.auth().currentUser.uid);
    ref.on("value", function(snapshot) {
       var addRes = firebase.database().ref("restaurants/"+snapshot.child('restaurant').val());
       let WaiterAdd = {
         email: email_id,
         salary: salary
       }
       addRes.child('waiters').push(WaiterAdd);
     }, function (error) {
       console.log("Error: " + error.code);
    });
  }

  function addFireKitchen(email_id,salary){
    var ref = firebase.database().ref('users/verified/'+firebase.auth().currentUser.uid);
    ref.on("value", function(snapshot) {
       var addRes = firebase.database().ref("restaurants/"+snapshot.child('restaurant').val());
       let WaiterAdd = {
         email: email_id,
         salary: salary
       }
       addRes.child('kitchen').push(WaiterAdd);
     }, function (error) {
       console.log("Error: " + error.code);
    });
  }

  var exOnce = (function() {
    var executed = false;
    return function() {
        if (!executed) {
            executed = true;
            getStaffOnLoad();
            getStaffOnLoadKitchen();
        }
    };
})();

  firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
      exOnce();
    }else{
      console.log("Nope");
    }
  });
}());
