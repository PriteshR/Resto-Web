(function() {
  const config = {
    apiKey: "AIzaSyAc5YOYrnvFgRcfXazXP52w9vxOUO4M1e0",
    authDomain: "resto-2eb0a.firebaseapp.com",
    databaseURL: "https://resto-2eb0a.firebaseio.com",
    projectId: "resto-2eb0a",
    storageBucket: "resto-2eb0a.appspot.com",
    messagingSenderId: "800932025890",
  };

  firebase.initializeApp(config);

  var name = getUrlValue()["custName"];
  var tname = getUrlValue()["tableName"];
  var itemsArray = new Array();
  var quantityArray = new Array();
  var categoryArray = new Array();
  function getItemsOnLoad(){
    var ref = firebase.database().ref('users/verified/'+firebase.auth().currentUser.uid);
    ref.on("value", function(snapshot) {
      var rootRef = firebase.database().ref();
      resid = snapshot.child('restaurant').val();
      var urlRef = rootRef.child("restaurants/"+resid+"/menu/items");
      urlRef.once("value", function(snapshot) {
        snapshot.forEach(function(child) {
          var name,price,category;
          var urlR = rootRef.child("restaurants/"+resid+"/menu/items/"+child.key);
          urlR.once("value", function(snapshot) {
          snapshot.forEach(function(child) {
                if(child.key=="name"){
                  name = child.val();
                }
                if(child.key=="price"){
                  price = child.val();
                }
                if(child.key=="category"){
                  category = child.val();
                }
            });
            AddItem(name,price,category,0);
          });
        });
      });
    });
  }

  document.getElementById("showAll").onclick = function(){
    var rowCount = document.getElementById("items").rows.length;
    for (var i = rowCount - 1; i > 0; i--) {
        document.getElementById("items").deleteRow(i);
    }
    getItemsOnLoad();
  };

  document.getElementById("sendOrder").onclick = function(){
    sendOrder();
  };

  function sendOrder(){
    console.log("sendOrder");
    var ref = firebase.database().ref('users/verified/'+firebase.auth().currentUser.uid);
    ref.on("value", function(snapshot) {
      console.log(snapshot.child('restaurant').val());

      var rootRef = firebase.database().ref();
      resid = snapshot.child('restaurant').val();

      var addRecord = firebase.database().ref("restaurants/"+resid+"/tables/"+tname);
      for(i=0;i<itemsArray.length;i++){
        console.log(i);
        let item = {
          name: itemsArray[i],
          category: categoryArray[i],
          quantity: quantityArray[i]
        }
        addRecord.child('RecentOrder').push(item);
      }
    });
  }

  function getUrlValue() {
    var vars = {};
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
        vars[key] = value;
    });
    return vars;
  }

  function getCategoriesOnLoad(){
    var ref = firebase.database().ref('users/verified/'+firebase.auth().currentUser.uid);
    ref.on("value", function(snapshot) {
      console.log(snapshot.child('restaurant').val());

      var rootRef = firebase.database().ref();
      resid = snapshot.child('restaurant').val();
      var urlRef = rootRef.child("restaurants/"+resid+"/menu/categories");
      urlRef.once("value", function(snapshot) {
        snapshot.forEach(function(child) {
          var name;
          var urlR = rootRef.child("restaurants/"+resid+"/menu/categories/"+child.key);
          urlR.once("value", function(snapshot) {
          snapshot.forEach(function(child) {
                if(child.key=="name"){
                  name = child.val();
                }
            });
            AddCategory(name,0);
          });
        });
      });
    });
  }

  function getItemsByCat(catName){
    var ref = firebase.database().ref('users/verified/'+firebase.auth().currentUser.uid);
    var rowCount = document.getElementById("items").rows.length;
    for (var i = rowCount - 1; i > 0; i--) {
        document.getElementById("items").deleteRow(i);
    }
    ref.on("value", function(snapshot) {
      var rootRef = firebase.database().ref();
      resid = snapshot.child('restaurant').val();
      var urlRef = rootRef.child("restaurants/"+resid+"/menu/items");
      urlRef.once("value", function(snapshot) {
        snapshot.forEach(function(child) {
          var name,price,category;
          var urlR = rootRef.child("restaurants/"+resid+"/menu/items/"+child.key);
          urlR.once("value", function(snapshot) {
          snapshot.forEach(function(child) {
                  if(child.key=="name"){
                    name = child.val();
                  }
                  if(child.key=="price"){
                    price = child.val();
                  }
                  if(child.key=="category"){
                    category = child.val();
                  }
            });
            if(category==catName){
              AddItem(name,price,category,0);
            }
          });
        });
      });
    });
  }

  function getCatList(){
    console.log("executed getCat");
    var name = [];
    name.length = 0;
    document.getElementById("categoryList").innerHTML = "";
    var ref = firebase.database().ref('users/verified/'+firebase.auth().currentUser.uid);
    ref.on("value", function(snapshot) {
      console.log(snapshot.child('restaurant').val());

      var rootRef = firebase.database().ref();
      resid = snapshot.child('restaurant').val();
      var urlRef = rootRef.child("restaurants/"+resid+"/menu/categories");
      urlRef.once("value", function(snapshot) {
        snapshot.forEach(function(child) {

          var urlR = rootRef.child("restaurants/"+resid+"/menu/categories/"+child.key);
          urlR.once("value", function(snapshot) {
          snapshot.forEach(function(child) {
                if(child.key=="name"){
                  name.push(child.val());
                  var x = document.getElementById("categoryList");
                  var c = document.createElement("option");
                  c.text = child.val();
                  x.options.add(c);
                  console.log(child.val());
                }
            });
          });
        });
      });
    });
  }
  console.log("These is staff");

  function AddItem(name,price,category,a){
    console.log('second');
    var table = document.getElementById("items");
    var tr = document.createElement("tr");
    var td2 = document.createElement("td");
    var txt2 = document.createTextNode(name);
    var td3 = document.createElement("td");
    var txt3 = document.createTextNode(category);
    var td4 = document.createElement("td");
    var txt4 = document.createTextNode(price);
    var td5 = document.createElement("td");
    td5.setAttribute('class',"td-actions text-right");
    var selectBut = document.createElement("BUTTON");
    var editImage = document.createElement("i");
    var editNode = document.createTextNode("add");
    editImage.setAttribute('class',"material-icons");
    editImage.appendChild(editNode);
    selectBut.appendChild(editImage);
    selectBut.setAttribute('id',"select");
    selectBut.setAttribute('data-toggle',"modal");
    selectBut.setAttribute('data-target',"#selectTable");
    selectBut.setAttribute('class',"btn btn-primary btn-link btn-sm");
    td3.setAttribute('class','text-primary');
    td2.appendChild(txt2);
    td3.appendChild(txt3);
    td4.appendChild(txt4);
    td5.appendChild(selectBut);
    tr.appendChild(td2);
    tr.appendChild(td3);
    tr.appendChild(td4);
    tr.appendChild(td5);
    table.appendChild(tr);
    for(var i = 1; i < table.rows.length; i++)
    {
       table.rows[i].onclick = function()
       {
            $('#selectOrder').modal('show');
            document.getElementById("quanity").value = "";
            var sname =  this.cells[0].innerHTML;
            var scat =  this.cells[1].innerHTML;
            var sprice =  this.cells[2].innerHTML;

            document.getElementById('addQuantity').onclick = function(){
              console.log(addQuantity);
              AddSelectedItems(sname,sprice,scat,document.getElementById('quanity').value);
            }
       };
    }
  }

  function AddSelectedItems(name,price,category,quantity){
    itemsArray.push(name);
    quantityArray.push(quantity);
    categoryArray.push(category);
    var table = document.getElementById("Selecteditems");
    var tr = document.createElement("tr");
    var td2 = document.createElement("td");
    var txt2 = document.createTextNode(name);
    var td3 = document.createElement("td");
    var txt3 = document.createTextNode(category);
    var td4 = document.createElement("td");
    var txt4 = document.createTextNode(quantity);
    var td5 = document.createElement("td");
    var txt5 = document.createTextNode(price);
    td3.setAttribute('class','text-primary');
    td2.appendChild(txt2);
    td3.appendChild(txt3);
    td4.appendChild(txt4);
    td5.appendChild(txt5);
    tr.appendChild(td2);
    tr.appendChild(td3);
    tr.appendChild(td4);
    tr.appendChild(td5);
    table.appendChild(tr);
  }

  function AddCategory(name){
    console.log('second');
    var table = document.getElementById("category");
    var tr = document.createElement("tr");
    var td2 = document.createElement("td");
    var txt2 = document.createTextNode(name);

    td2.appendChild(txt2);
    tr.appendChild(td2);
    table.appendChild(tr);

    for(var i = 1; i < table.rows.length; i++)
    {
       table.rows[i].onclick = function()
       {
         console.log(this.cells[0].innerHTML);
         getItemsByCat(this.cells[0].innerHTML);
       };
    }
  }

  var exOnce = (function() {
    var executed = false;
    return function() {
        if (!executed) {
            executed = true;
            getItemsOnLoad();
            getCategoriesOnLoad();
            getCatList();
        }
    };
})();

  firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
      exOnce();
    }else{
      console.log("Nope");
    }
  });
}());
