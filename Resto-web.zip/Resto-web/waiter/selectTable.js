(function() {
  const config = {
    apiKey: "AIzaSyAc5YOYrnvFgRcfXazXP52w9vxOUO4M1e0",
    authDomain: "resto-2eb0a.firebaseapp.com",
    databaseURL: "https://resto-2eb0a.firebaseio.com",
    projectId: "resto-2eb0a",
    storageBucket: "resto-2eb0a.appspot.com",
    messagingSenderId: "800932025890",
  };

  firebase.initializeApp(config);

  function getTableOnLoad(){
    var ref = firebase.database().ref('users/verified/'+firebase.auth().currentUser.uid);
    ref.on("value", function(snapshot) {
      console.log(snapshot.child('restaurant').val());

      var rootRef = firebase.database().ref();
      resid = snapshot.child('restaurant').val();
      var urlRef = rootRef.child("restaurants/"+resid+"/tables");
      urlRef.once("value", function(snapshot) {
        snapshot.forEach(function(child) {
          var email,salary;
          console.log(child.key);
          var urlR = rootRef.child("restaurants/"+resid+"/tables/"+child.key);
          urlR.once("value", function(snapshot) {
          snapshot.forEach(function(child) {
                if(child.key=="name"){
                  email = child.val();
                }
                if(child.key=="seating"){
                  salary = child.val();
                }
            });
            AddTable(document.getElementById('Tables'),email,salary);
          });
        });
      });
    });
  }

  function AddTable(table,name,seating){
    console.log('second');
    var table = table;
    var tr = document.createElement("tr");
    var td2 = document.createElement("td");
    var txt2 = document.createTextNode(name);
    var td3 = document.createElement("td");
    var txt3 = document.createTextNode(seating);
    var td5 = document.createElement("td");
    td5.setAttribute('class',"td-actions text-right");
    var selectBut = document.createElement("BUTTON");
    var editImage = document.createElement("i");
    var editNode = document.createTextNode("add");
    editImage.setAttribute('class',"material-icons");
    editImage.appendChild(editNode);
    selectBut.appendChild(editImage);
    selectBut.setAttribute('id',"select");
    selectBut.setAttribute('data-toggle',"modal");
    selectBut.setAttribute('data-target',"#selectTable");
    selectBut.setAttribute('class',"btn btn-primary btn-link btn-sm");
    td3.setAttribute('class','text-primary');
    td2.appendChild(txt2);
    td3.appendChild(txt3);
    td5.appendChild(selectBut);
    tr.appendChild(td2);
    tr.appendChild(td3);
    tr.appendChild(td5);
    table.appendChild(tr);

    for(var i = 1; i < table.rows.length; i++)
    {
       table.rows[i].onclick = function()
       {
            $('#selectTable').modal('show');
            document.getElementById("custName").value = "";
            var tname = this.cells[0].innerHTML;
            document.getElementById('addCust').onclick = function(){
              console.log("executed");
              var ref = firebase.database().ref('users/verified/'+firebase.auth().currentUser.uid);
              ref.on("value", function(snapshot) {
                console.log(snapshot.child('restaurant').val());
                var rootRef = firebase.database().ref();
                resid = snapshot.child('restaurant').val();
                var urlRef = rootRef.child("restaurants/"+resid+"/tables");
                urlRef.once("value", function(snapshot) {
                  snapshot.forEach(function(child) {
                    var email,salary;
                    console.log("key--"+child.key);
                    var tableKey = child.key;
                    var urlR = rootRef.child("restaurants/"+resid+"/tables/"+child.key);
                    urlR.once("value", function(snapshot) {
                       snapshot.forEach(function(child){
                          if(child.key=="name"){
                            var childv = child.val();
                            if(childv==tname){
                              firebase.database().ref("restaurants/"+resid+"/tables/"+snapshot.key).update({
                                custName : document.getElementById('custName').value
                              });
                              location.href = "selectOrder.html"+"?custName="+document.getElementById('custName').value+"&tableName="+tableKey;
                            }
                          }
                      });
                    });
                  });
                });
              });
            }
       };
    }
  }

  var exOnce = (function() {
    var executed = false;
    return function() {
        if (!executed) {
            executed = true;
            getTableOnLoad();
        }
    };
  })();

  firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
      exOnce();
    }else{
      console.log("Nope");
    }
  });
}());
